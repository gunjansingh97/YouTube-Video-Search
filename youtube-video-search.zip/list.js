//stores the list of objects into json_obj after every fetch from youtube API
export function update(json_obj,settings){

  var pg = require('pg');
  var pgClient = new pg.Client(settings['db_con']);
  pgClient.connect();
const fs = require('fs');

var i;
var entry = "";
if(json_obj.items.length==0) {
  console.log("no data recieved");
  return;}
for(i in json_obj.items){
  // skip the record before insertion into db to avoid undefined values for main parameters
if(json_obj.items[i].id.videoId==undefined || json_obj.items[i].snippet.thumbnails.medium.height==undefined || json_obj.items[i].snippet.thumbnails.default.height==undefined || json_obj.items[i].snippet.thumbnails.high.height==undefined || json_obj.items[i].snippet.thumbnails.medium.width==undefined || json_obj.items[i].snippet.thumbnails.default.width==undefined || json_obj.items[i].snippet.thumbnails.high.width==undefined)
{continue;}
var desc=json_obj.items[i].snippet.description.replace(/'/g,"''");
//create an entry from the object received with all the required parameters
entry= entry+"('"+json_obj.items[i].id.videoId+"', '"+json_obj.items[i].id.kind+"', '"+json_obj.items[i].snippet.publishedAt+"', '"+json_obj.items[i].snippet.channelId+"', '"+json_obj.items[i].snippet.title+"', '"+desc+"', '"+json_obj.items[i].snippet.thumbnails.default.url+"',"+json_obj.items[i].snippet.thumbnails.default.height+","+json_obj.items[i].snippet.thumbnails.default.width+",'"+json_obj.items[i].snippet.thumbnails.medium.url+"',"+json_obj.items[i].snippet.thumbnails.medium.height+","+json_obj.items[i].snippet.thumbnails.medium.width+",'"+json_obj.items[i].snippet.thumbnails.high.url+"',"+json_obj.items[i].snippet.thumbnails.high.height+","+json_obj.items[i].snippet.thumbnails.high.width+"),";
}
//insert into the table in db
var query="INSERT INTO yt_cricket VALUES"+entry.slice(0, -1);
//avoid duplicate entries to fetch unique results for the user
query=query+"ON CONFLICT (video_id) DO NOTHING"

pgClient.query(query, (err, res) => {
    if (err) throw err
    console.log(res)
    pgClient.end()
  });
  if(json_obj.nextPageToken!=''){
    //update the token to fetch a paginated response from the API call
    fs.writeFileSync('be_config.json', JSON.stringify({"api_key":settings['api_key'],"token":json_obj.nextPageToken,"db_con":settings['db_con']}));
    console.log("data written");
    }    
}



export function search(){
  console.log("calling youtube API now");
const fs = require('fs');
var settings=JSON.parse(fs.readFileSync('be_config.json'));
var token='';
//next page token to be added if present for paginated response
if(settings.token!=''){
  token='&pageToken='+settings['token'];
}

//API call for data from youtube
const url="https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=50&order=date"+token+"&q=cricket&key="+settings['api_key']
console.log(url);
const options = {
    headers: {
      Accept: "application/json"
      
    }
  };

 const fetch = require("node-fetch");
  fetch(url, options)
  .then( res => res.json() )
  .then( data => update(data,settings) );}