import {update} from "./list.js";
import {search} from "./list.js";
var express = require('express');
const http = require('http');
var app = express();
var bodyParser = require('body-parser');
app.engine('html', require('ejs').renderFile);
var path = require('path');

const hostname = '127.0.0.2';
const port = 3000;
const fs = require('fs');
var settings=JSON.parse(fs.readFileSync('be_config.json'));
var pg = require('pg');
  var pgClient = new pg.Client(settings['db_con']); // db config properties 
  pgClient.connect();

  app.use(bodyParser.urlencoded({
    extended:true
  }));

  //publishes the results of the query on the UI based on user search input
  app.get('/', function(req,results){
    results.render('index.html',{list:results});
  });

  // takes the user input and executes the query with that user search input to publish results
  app.post('/', function(req, res) {
    pgClient.query("SELECT * FROM yt_cricket WHERE description LIKE '%" + req.body.userSearchInput + "%'", function (error, results) {
      if (error) throw error;
      console.log(results);
      });
  });

//server listening to port 3000
var server = app.listen(3000, function(){ //Start the server on port 3000
  console.log('server has started on localhost:3000...');
  //search call to youtube after every 10 seconds to fetch data and store in DB
  setInterval(search, 100000);
});